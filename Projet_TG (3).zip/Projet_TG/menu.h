#ifndef PROJET_TG_MENU_H
#define PROJET_TG_MENU_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

const char* choose_network();

#endif //PROJET_TG_MENU_H
