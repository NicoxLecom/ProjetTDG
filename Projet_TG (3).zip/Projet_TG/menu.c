#include "menu.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define CONSOLE_WIDTH 80

const char* choose_network() {
    int choice;
    system("cls");
    printf("===================================\n", CONSOLE_WIDTH);
    printf(" SELECTION DU RESEAU TROPHIQUE \n", CONSOLE_WIDTH);
    printf("===================================\n", CONSOLE_WIDTH);
    printf("1. Réseau de Prairie\n", CONSOLE_WIDTH);
    printf("2. Réseau de Savane\n", CONSOLE_WIDTH);
    printf("3. Réseau Marin\n", CONSOLE_WIDTH);
    printf("===================================\n", CONSOLE_WIDTH);
    printf("Choisissez un réseau : \n", CONSOLE_WIDTH);

    scanf("%d", &choice);

    switch (choice) {
        case 1: return "prairie.txt";
        case 2: return "savane.txt";
        case 3: return "marin.txt";
        default:
            printf("Option invalide. Réseau par défaut (prairie) sélectionné.\n");
            return "prairie.txt";
    }
}
