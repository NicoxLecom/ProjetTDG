#ifndef PROJET_TG_FONCTIONS_H
#define PROJET_TG_FONCTIONS_H

typedef struct {
    char name[50];
    char type[50];
    double population;
    double growth_rate;
    double carrying_capacity;
    double mortality_rate; // Nouveau champ pour le taux de mortalité
} Node;


typedef struct {
    int start;         // Index du sommet de départ
    int end;           // Index du sommet d'arrivé
    double coefficient; // Coefficient de relation (ou autre métrique)
} Edge;

void display_predator_prey_relationships(Node *nodes, int node_count, Edge *edges, int edge_count);
void print_centered(const char *text, int width);
void load_network(const char *filename, Node **nodes, int *node_count, Edge **edges, int *edge_count);
void save_network(const char *filename, Node *nodes, int node_count, Edge *edges, int edge_count);
void display_network(Node *nodes, int node_count, Edge *edges, int edge_count);
void analyze_network(Node *nodes, int node_count, Edge *edges, int edge_count);
void simulate_population(Node *nodes, int node_count, Edge *edges, int edge_count, int steps);
void display_graph(const char *dot_file, const char *output_image);
void dfs(int node, int *visited, Edge *edges, int edge_count);
void display_node_details(Node *nodes, int node_count, Edge *edges, int edge_count);

#endif //PROJET_TG_FONCTIONS_H