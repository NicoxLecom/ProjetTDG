#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "fonctions.h"
#include "simulation.h"
#include "menu.h"

#define CONSOLE_WIDTH 80
void print_menu() {
    system("cls"); // Utilisez "cls" si vous êtes sous Windows
    print_centered("===================================", CONSOLE_WIDTH);
    print_centered(" SIMULATEUR DE RESEAUX TROPHIQUES ", CONSOLE_WIDTH);
    print_centered("===================================", CONSOLE_WIDTH);
    print_centered("1. Charger un reseau trophique", CONSOLE_WIDTH);
    print_centered("2. Sauvegarder le reseau actuel", CONSOLE_WIDTH);
    print_centered("3. Afficher le réseau actuel (texte)", CONSOLE_WIDTH);
    print_centered("4. Analyser le réseau actuel", CONSOLE_WIDTH);
    print_centered("5. Simuler la dynamique des populations", CONSOLE_WIDTH);
    print_centered("6. Afficher le graphe associe", CONSOLE_WIDTH);
    print_centered("7. Afficher les relations predateur-proie", CONSOLE_WIDTH); // New optio
    print_centered("8. Selectionner un animal et afficher ses relations",CONSOLE_WIDTH);
    print_centered("9. Quitter", CONSOLE_WIDTH);
    printf("\n");
    print_centered("Choisissez une option : ", CONSOLE_WIDTH);
}

int main() {
    int choice;
    Node *nodes = NULL;
    Edge *edges = NULL;
    int node_count = 0, edge_count = 0;
    const char *current_network = NULL;
    const char *dot_file = NULL;

    do {
        print_menu();
        scanf("%d", &choice);
        getchar(); // Pour nettoyer le buffer

        switch (choice) {
            case 1: // Charger un réseau
                current_network = choose_network();
                load_network(current_network, &nodes, &node_count, &edges, &edge_count);
                if (strcmp(current_network, "prairie.txt") == 0) {
                    dot_file = "prairie.dot";
                } else if (strcmp(current_network, "savane.txt") == 0) {
                    dot_file = "savane.dot";
                } else if (strcmp(current_network, "marin.txt") == 0) {
                    dot_file = "marin.dot";
                }
                break;
            case 2: // Sauvegarder le réseau
                save_network("network_saved.txt", nodes, node_count, edges, edge_count);
                break;
            case 3: // Afficher le réseau
                if (current_network) {
                    display_network(nodes, node_count, edges, edge_count);
                } else {
                    printf("\nAucun reseau chargé.\n");
                }
                break;
            case 4: // Analyser le réseau
                if (current_network) {
                    analyze_network(nodes, node_count, edges, edge_count);
                } else {
                    printf("\nAucun reseau chargé.\n");
                }
                break;
            case 5: // Simuler les dynamiques
                if (current_network) {
                    simulate_population(nodes, node_count, edges, edge_count, 10); // Par exemple, 100 étapes max
                } else {
                    printf("\nAucun reseau chargé.\n");
                }
                break;
            case 6: // Afficher le graphe associé
                if (dot_file) {
                    printf("\nAffichage du graphe associe...\n");
                    display_graph(dot_file, "output.png");
                    printf("Le graphe a été ouvert dans votre visionneuse d images.\n");
                } else {
                    printf("\nAucun reseau chargé pour afficher le graphe.\n");
                }
                break;
            case 7: // Afficher les relations prédateur-proie
                if (current_network) {
                    display_predator_prey_relationships(nodes, node_count, edges, edge_count);
                } else {
                    printf("\nAucun réseau charge.\n");
                }
                break;
            case 8: { // Sélectionner un animal et afficher ses relations
                if (nodes && edges)  { // Sélectionner un animal et afficher ses relations
                    if (nodes && edges) {
                        display_node_details(  nodes, node_count, edges, edge_count);
                    } else {
                        printf("Aucun reseau charge pour cette option.\n");
                    }
                    break;
                }
            }
            case 9:
                printf("\nAu revoir !\n");
                break;
            default:
                printf("\nOption invalide. Veuillez reessayer.\n");
        }

        if (choice != 9) {
            printf("\nAppuyez sur Entree pour revenir au menu...");
            getchar();
        }
    } while (choice != 9);

    free(nodes);
    free(edges);
    return 0;
}