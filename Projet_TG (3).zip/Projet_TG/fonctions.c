#include "fonctions.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "fonctions.h"
#include "simulation.h"
void display_predator_prey_relationships(Node *nodes, int node_count, Edge *edges, int edge_count) {
    printf("\n--- Relations Prédateur-Proie ---\n");
    for (int i = 0; i < node_count; i++) {
        printf("%s (%s):\n", nodes[i].name, nodes[i].type);
        printf("  Mange : ");
        int found_prey = 0;
        for (int j = 0; j < edge_count; j++) {
            if (edges[j].end == i) {
                printf("%s ", nodes[edges[j].start].name);
                found_prey = 1;
            }
        }
        if (!found_prey) {
            printf("Aucun");
        }
        printf("\n  Est mangé par : ");
        int found_predator = 0;
        for (int j = 0; j < edge_count; j++) {
            if (edges[j].start == i) {
                printf("%s ", nodes[edges[j].end].name);
                found_predator = 1;
            }
        }
        if (!found_predator) {
            printf("Aucun");
        }
        printf("\n");
    }
    printf("\n--- Fin des Relations ---\n");
}

void print_centered(const char *text, int width) {
    int padding = (width - strlen(text)) / 2;
    for (int i = 0; i < padding; i++) {
        printf(" ");
    }
    printf("%s\n", text);
}void load_network(const char *filename, Node **nodes, int *node_count, Edge **edges, int *edge_count) {
    FILE *file = fopen(filename, "r");
    if (!file) {
        printf("Erreur : impossible de charger le fichier %s\n", filename);
        return;
    }

    fscanf(file, "%d %d", node_count, edge_count);
    *nodes = (Node *)malloc(*node_count * sizeof(Node));
    *edges = (Edge *)malloc(*edge_count * sizeof(Edge));

    for (int i = 0; i < *node_count; i++) {
        fscanf(file, "%s %s %lf %lf %lf %lf",
               (*nodes)[i].name,
               (*nodes)[i].type,
               &(*nodes)[i].population,
               &(*nodes)[i].growth_rate,
               &(*nodes)[i].carrying_capacity,
               &(*nodes)[i].mortality_rate);
    }

    for (int i = 0; i < *edge_count; i++) {
        fscanf(file, "%d %d %lf", &(*edges)[i].start, &(*edges)[i].end, &(*edges)[i].coefficient);
    }

    fclose(file);
    printf("Réseau chargé avec succès depuis %s\n", filename);
}
void save_network(const char *filename, Node *nodes, int node_count, Edge *edges, int edge_count) {
    FILE *file = fopen(filename, "w");
    if (!file) {
        printf("Erreur : impossible de sauvegarder dans le fichier %s\n", filename);
        return;
    }

    fprintf(file, "%d %d\n", node_count, edge_count);

    for (int i = 0; i < node_count; i++) {
        fprintf(file, "%s %s %.2lf %.2lf %.2lf\n",
                nodes[i].name,
                nodes[i].type,
                nodes[i].population,
                nodes[i].growth_rate,
                nodes[i].carrying_capacity);
    }

    for (int i = 0; i < edge_count; i++) {
        fprintf(file, "%d %d %.2lf\n", edges[i].start, edges[i].end, edges[i].coefficient);
    }

    fclose(file);
    printf("Réseau sauvegardé avec succès dans %s\n", filename);
}

void display_network(Node *nodes, int node_count, Edge *edges, int edge_count) {
    printf("Noeuds (%d) :\n", node_count);
    for (int i = 0; i < node_count; i++) {
        printf("  %s (%s) Population: %.2lf, Croissance: %.2lf, Capacité: %.2lf\n",
               nodes[i].name, nodes[i].type, nodes[i].population, nodes[i].growth_rate, nodes[i].carrying_capacity);
    }

    printf("\nArcs (%d) :\n", edge_count);
    for (int i = 0; i < edge_count; i++) {
        printf("  %s -> %s Coefficient: %.2lf\n",
               nodes[edges[i].start].name, nodes[edges[i].end].name, edges[i].coefficient);
    }
}
void analyze_network(Node *nodes, int node_count, Edge *edges, int edge_count) {
    printf("\n--- Analyse du Reseau Trophique ---\n");

    // **1. Connexité simple**
    int *visited = calloc(node_count, sizeof(int));


    int is_connected = 1;
    for (int i = 0; i < node_count; i++) {
        if (!visited[i]) {
            is_connected = 0;
            break;
        }
    }
    printf("Le reseau est %sconnexe.\n", is_connected ? "" : "non ");
    free(visited);

    // **2. Trouver les producteurs primaires**
    printf("\nProducteurs primaires :\n");
    for (int i = 0; i < node_count; i++) {
        int has_predecessors = 0;
        for (int j = 0; j < edge_count; j++) {
            if (edges[j].end == i) {
                has_predecessors = 1;
                break;
            }
        }
        if (!has_predecessors) {
            printf("  - %s\n", nodes[i].name);
        }
    }

    // **3. Trouver les prédateurs**
    printf("\nPredateurs finaux :\n");
    for (int i = 0; i < node_count; i++) {
        int has_successors = 0;
        for (int j = 0; j < edge_count; j++) {
            if (edges[j].start == i) {
                has_successors = 1;
                break;
            }
        }
        if (!has_successors) {
            printf("  - %s\n", nodes[i].name);
        }
    }

    // **4. Densité de liaison**
    double density = (double)edge_count / (node_count * (node_count - 1));
    printf("\nDensite de liaison : %.2f\n", density);

    // **5. Niveaux trophiques**
    printf("\nNiveaux trophiques :\n");
    for (int i = 0; i < node_count; i++) {
        int level = 0;
        int current = i;

        while (1) {
            int found_predecessor = 0;
            for (int j = 0; j < edge_count; j++) {
                if (edges[j].end == current) {
                    current = edges[j].start;
                    found_predecessor = 1;
                    level++;
                    break;
                }
            }
            if (!found_predecessor) break;
        }

        printf("  - %s : Niveau trophique %d\n", nodes[i].name, level);
    }

    printf("\n--- Fin de l'Analyse ---\n");
}

// Implémentation de la fonction dfs
void dfs(int node, int *visited, Edge *edges, int edge_count) {
    visited[node] = 1;
    for (int i = 0; i < edge_count; i++) {
        if (edges[i].start == node && !visited[edges[i].end]) {
            dfs(edges[i].end, visited, edges, edge_count);
        }
    }
}




void display_graph(const char *dot_file, const char *output_file) {
    char command[256];
    snprintf(command, sizeof(command), "dot -Tpng %s -o %s", dot_file, output_file);
    if (system(command) != 0) {
        printf("Erreur : Impossible de générer l'image à partir du fichier DOT.\n");
    } else {
        printf("Image générée avec succès : %s\n", output_file);
        snprintf(command, sizeof(command), "start %s", output_file); // Pour Windows
        system(command);
    }
}



void display_node_details(Node *nodes, int node_count, Edge *edges, int edge_count) {
    int selected_node;

    printf("\n--- Sélection d'un animal ou d'une ressource ---\n");
    for (int i = 0; i < node_count; i++) {
        printf("  %d: %s\n", i, nodes[i].name);
    }
    printf("\nEntrez l'indice de l'animal ou de la ressource à analyser (0 à %d) : ", node_count - 1);
    scanf("%d", &selected_node);

    if (selected_node < 0 || selected_node >= node_count) {
        printf("Erreur : l'indice est invalide.\n");
        return;
    }

    printf("\n--- Détails pour '%s' ---\n", nodes[selected_node].name);

    // Liste des successeurs (prédation par le sommet sélectionné)
    printf("Mange (successeurs) :\n");
    int found_successor = 0;
    for (int i = 0; i < edge_count; i++) {
        if (edges[i].end == selected_node) {
            printf("  - %s (Coefficient: %.2lf)\n", nodes[edges[i].start].name, edges[i].coefficient);
            found_successor = 1;
        }
    }
    if (!found_successor) {
        printf("  Aucun.\n");
    }

    // Liste des prédécesseurs (sommet sélectionné est mangé par)
    printf("Est mangé par (prédécesseurs) :\n");
    int found_predecessor = 0;
    for (int i = 0; i < edge_count; i++) {
        if (edges[i].start == selected_node) {
            printf("  - %s (Coefficient: %.2lf)\n", nodes[edges[i].end].name, edges[i].coefficient);
            found_predecessor = 1;
        }
    }
    if (!found_predecessor) {
        printf("  Aucun.\n");
    }

    printf("\n--- Fin de l'analyse ---\n");
    printf("\nAppuyez sur Entree pour revenir au menu...");
    getchar();
}
