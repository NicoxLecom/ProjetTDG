#ifndef PROJET_TG_SIMULATION_H
#define PROJET_TG_SIMULATION_H

#include "fonctions.h"

void simulate_population(Node *nodes, int node_count, Edge *edges, int edge_count, int steps);


#endif //PROJET_TG_SIMULATION_H
