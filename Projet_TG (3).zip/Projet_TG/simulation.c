#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include "simulation.h"
#include "fonctions.h"

void simulate_population(Node *nodes, int node_count, Edge *edges, int edge_count, int max_steps) {
    printf("=== Parametres initiaux ===\n");
    for (int i = 0; i < node_count; i++) {
        printf("  %s (%s): Population = %.2f, Croissance = %.2f, Capacite = %.2f\n",
               nodes[i].name, nodes[i].type, nodes[i].population, nodes[i].growth_rate, nodes[i].carrying_capacity);
    }

    for (int step = 1; step <= max_steps; step++) {
        printf("\n=== Etape %d ===\n", step);

        double *new_populations = (double *)calloc(node_count, sizeof(double));
        double *waste_generated = (double *)calloc(node_count, sizeof(double)); // Gestion des déchets.

        printf("Section 1 : Croissance des especes\n");
        for (int i = 0; i < node_count; i++) {
            new_populations[i] = nodes[i].population;

            if (strcmp(nodes[i].type, "Source") == 0 || strcmp(nodes[i].name, "Soleil") == 0) {
                continue;
            }

            // Croissance logistique pour tous les types
            double growth = nodes[i].growth_rate * nodes[i].population *
                            (1 - nodes[i].population / (nodes[i].carrying_capacity + 1e-9));
            new_populations[i] += fmax(0, growth);

            // Régénération passive si sous le seuil critique
            if (new_populations[i] < nodes[i].carrying_capacity * 0.2) {
                new_populations[i] += nodes[i].carrying_capacity * 0.05; // Régénération pour éviter extinction.
            }

            // Affichage compact
            printf("  %s: %.2f -> %.2f (croissance = %.2f)\n",
                   nodes[i].name, nodes[i].population, new_populations[i], growth);
        }

        printf("\nSection 2 : Interactions sous forme d arcs\n");
        for (int j = 0; j < edge_count; j++) {
            int predator = edges[j].end;
            int prey = edges[j].start;

            double max_possible_consumption = fmin(
                edges[j].coefficient * nodes[predator].population,
                nodes[prey].population * 0.05 // Limitation à 5% de la population de proie.
            );

            double actual_consumption = fmin(max_possible_consumption, nodes[prey].population);
            new_populations[prey] -= actual_consumption;
            new_populations[predator] += actual_consumption * 0.4; // Conversion améliorée en croissance des prédateurs.
            waste_generated[prey] += actual_consumption * 0.6;    // 60% des consommations deviennent des déchets.

            // Affichage sous forme d’arc
            printf("  %s -> %s : Consomme = %.2f, Gain = %.2f\n",
                   nodes[predator].name, nodes[prey].name, actual_consumption, actual_consumption * 0.4);
        }

        // Gestion des déchets organiques
        for (int i = 0; i < node_count; i++) {
            if (strcmp(nodes[i].name, "Dechets_Organiques") == 0) {
                double total_waste = 0.0;
                for (int j = 0; j < node_count; j++) {
                    total_waste += waste_generated[j];
                }
                new_populations[i] += total_waste * 0.8; // Augmentation du recyclage vers les producteurs.
                printf("  Dechets organiques recycles : %.2f\n", total_waste * 0.8);
                break;
            }
        }

        printf("\nSection 3 : Mise a jour des populations\n");
        for (int i = 0; i < node_count; i++) {
            if (new_populations[i] < 1e-3) {
                new_populations[i] = 0.0;
            } else if (new_populations[i] > nodes[i].carrying_capacity) {
                new_populations[i] = nodes[i].carrying_capacity;
            }

            // Mise à jour de la population et affichage
            printf("  %s (%s): %.2f -> %.2f\n",
                   nodes[i].name, nodes[i].type, nodes[i].population, new_populations[i]);
            nodes[i].population = new_populations[i];
        }

        free(new_populations);
        free(waste_generated);
    }
}
